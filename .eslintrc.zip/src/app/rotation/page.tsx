import Rotate from "../_components/Rotate";

export default function Rotation() {
    return <Rotate />;
}
